# Booth Voter Search – Avadi Part 194

A starter Android Studio project for local/offline searching of a user-selected electoral-roll PDF.

## Important
- This project imports the PDF on the phone and stores extracted records locally in app preferences.
- It does not upload or transmit voter records.
- The PDF contains personal data. Install only on trusted devices, use a device screen lock, and do not share the APK/database or search results publicly.
- PDF text extraction and card parsing are best-effort. The first import must be checked against the original PDF. The parser may miss records if text order/layout differs.
- The app deliberately does not provide voter profiling, political targeting, or bulk export.

## Build APK (free)
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Android Studio download the Gradle and PDFBox dependencies.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated debug APK on your Android phone.
6. In the app, tap **IMPORT ELECTORAL ROLL PDF** and select the Booth 194 PDF.

## Current app scope
- Offline PDF import
- Search by name, EPIC, serial number, house number, and relative name
- Local saved records
- English UI

This is a starter implementation, not a certified Election Commission application. Verify every search result against the official roll before relying on it.

## Build APK from your phone using GitHub Actions
1. Create a GitHub repository (public is easiest for free Actions minutes).
2. Upload all files and folders from this project ZIP to the repository root, including the hidden `.github/workflows/build-apk.yml` file.
3. Open the repository in Chrome, select **Actions**, then **Build Booth Voter Search APK**, and choose **Run workflow**.
4. When the run completes, open it and download the `Booth-Voter-Search-debug-apk` artifact.
5. Extract the artifact ZIP on your phone and install `app-debug.apk`.
